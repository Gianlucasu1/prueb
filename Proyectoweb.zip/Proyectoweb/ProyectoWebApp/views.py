from django.shortcuts import render, HttpResponse

def home(request):
    
    return render(request, "ProyectoWebAPP/home.html")

def home1(request):
    
    return render(request, "ProyectoWebAPP/index.html")

def tienda(request):
    
    return render(request, "ProyectoWebAPP/tienda.html")

def blog(request):
    
    return render(request, "ProyectoWebAPP/blog.html")

def contacto(request):
    
    return render(request, "ProyectoWebAPP/contacto.html")
# Create your views here.
