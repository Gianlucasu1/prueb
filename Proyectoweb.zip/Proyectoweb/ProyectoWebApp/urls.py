from django.urls import path
from ProyectoWebApp import views
from django.conf import settings
from django.conf.urls.static import static

app_name='home'

urlpatterns = [
    path('home1', views.home1, name ="Home1"),
    path('tienda', views.tienda, name ="Tienda"),
    path('blog', views.blog, name ="Blog"),
    path('contacto', views.contacto, name ="Contacto"),
]
 
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)