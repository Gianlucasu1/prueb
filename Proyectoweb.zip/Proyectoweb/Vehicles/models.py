from django.db import models


class Vehicle (models.Model):

    mark=models.CharField(max_length=50)
    model=models.CharField(max_length=50)
    price=models.FloatField()
    city=models.CharField(max_length=50)
    image=models.ImageField(upload_to = 'vehicles')


    class Meta:
        verbose_name="vehicle"
        verbose_name_plural="vehicles"

    def __str__(self):
        return self.mark

# Create your models here.
