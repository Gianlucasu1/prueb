from django.shortcuts import render,redirect
from Vehicles.models import Vehicle
from .forms import CreateVehicleForm

def vehicles(request):
    
    vehicles=Vehicle.objects.all()
    num = 0
    return render(request, "vehi/vehicles.html",{"vehicles":vehicles, "numero":num})


def edit_vehicle (request, pk):

    
    vehicle = Vehicle.objects.get(id=pk)
    form = CreateVehicleForm(instance=vehicle)

    if request.method == 'POST':
        form = CreateVehicleForm(request.POST,request.FILES, instance=vehicle)
        if form.is_valid():
            form.save()
            return redirect('vehicles:CreateVehicle')
     
    return render(request, "vehi/edit_vehicle.html",{"form":form})


def delete_vehicle (request, pk):
    
    vehicle = Vehicle.objects.get(id=pk)
    if request.method =='POST':
        vehicle.delete()
        return redirect('vehicles:VehiclesUpdate')

    return render(request, "vehi/delete_vehicle.html",{"vehicle":vehicle})


def vehicles_update(request):
    
    vehicles=Vehicle.objects.all()
    num = 0
    return render(request, "vehi/vehicles_update.html",{"vehicles":vehicles, "numero":num})


def create_vehicle(request):

    form = CreateVehicleForm()

    if request.method == 'POST':
        form = CreateVehicleForm(request.POST,request.FILES)

        if form.is_valid():
            form.save()
            return redirect('vehicles:CreateVehicle')
    
    return render(request, "vehi/create_vehicle.html",{"form":form})


# Create your views here.
