from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

app_name='vehicles'


urlpatterns = [
    path('delete_vehicle/<str:pk>/', views.delete_vehicle, name ="DeleteVehicle"),
    path('edit_vehicle/<str:pk>/', views.edit_vehicle, name ="EditVehicle"),
    path('vehicles_update/', views.vehicles_update, name ="VehiclesUpdate"),
    path('vehicles/', views.vehicles, name ="Vehicles"),
    path('create_vehicle/', views.create_vehicle, name ="CreateVehicle"),
]

