from django.forms import ModelForm
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *


class CreateVehicleForm (ModelForm):
    
	class Meta:
		model = Vehicle
		
		fields = '__all__'