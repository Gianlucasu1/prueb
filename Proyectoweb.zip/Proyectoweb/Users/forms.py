from django.forms import ModelForm
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import *

class Form_register(forms.Form):

    nombre = forms.CharField(label='nombre', max_length=100, required = True)
    apellidos = forms.CharField(label='apellidos', max_length=100, required = True)
    documento = forms.IntegerField(label='documento', required = True)
    fecha_nac = forms.CharField(label='fecha_nac', max_length=100, required = True)
    direccion = forms.CharField(label='direccion', max_length=100, required = True)
    email = forms.CharField(label='email', max_length=100, required = True)
    contraseña = forms.CharField(label='contraseña', max_length=100, required = True)

class Form_login(forms.Form):
    
    user = forms.CharField(label='user', max_length=100, required = True)
    password = forms.CharField(label='password', max_length=100, required = True)

class CreateUserForm(UserCreationForm):
    class Meta:
        model=User
        fields =['username','email','password1','password2']

class User_Form (ModelForm):
    
	class Meta:
		model = Users
		exclude =('usuario','correo', 'admin')
		fields = '__all__'
