from django.db import models
from django.contrib.auth.models import User


class Users(models.Model):

    usuario=models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
    nombre=models.CharField(max_length=50)
    apellidos=models.CharField(max_length=50)
    num_documento=models.IntegerField()
    fecha_nac=models.CharField(max_length=50)
    direccion=models.CharField(max_length=50)
    correo=models.CharField(max_length=50)
    admin=models.BooleanField(default=False)


    class Meta:
        verbose_name="User"
        verbose_name_plural="Users"

    def __str__(self):
        return self.nombre


class Users2(models.Model):
    
    usuario=models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
    nombre=models.CharField(max_length=50)
    apellidos=models.CharField(max_length=50)
    num_documento=models.IntegerField()
    fecha_nac=models.CharField(max_length=50)
    direccion=models.CharField(max_length=50)
    correo=models.CharField(max_length=50)
    admin=models.BooleanField()


    class Meta:
        verbose_name="User2"
        verbose_name_plural="Users2"

    def __str__(self):
        return self.nombre


# Create your models here.
