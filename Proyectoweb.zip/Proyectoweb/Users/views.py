from django.shortcuts import render,redirect
from .forms import Form_register,Form_login
from Users.models import Users
from django.contrib.auth.forms import UserCreationForm
from .forms import CreateUserForm, User_Form
from django.views.generic import FormView
from django.contrib.auth import authenticate,login,logout
from django.urls import reverse_lazy
from django.contrib import messages
from Vehicles.models import Vehicle
from django.contrib.auth.decorators import login_required



def show_vehicles(request):
    
    vehicles=Vehicle.objects.all()
    num = 0
    return render(request, "users/disp_vehiculos.html",{"vehicles":vehicles, "numero":num})


def users(request):
    
    users=Users.objects.all()
    return render(request, "users/login.html",{"users":users})


@login_required(login_url = 'users:Login')
def dashboard(request):
    
    
    return render(request, "users/dashboard.html")


def register(request):

    formulario_registro=Form_register()
    if request.method == "POST":
        formulario_registro=Form_register(data=request.POST)

        if formulario_registro.is_valid():
            nombre=request.POST.get("nombre")
            apellidos=request.POST.get("apellidos")
            documento=request.POST.get("documento")
            fecha_nac=request.POST.get("fecha_nac")
            direccion=request.POST.get("direccion")
            email=request.POST.get("email")
            contraseña=request.POST.get("contraseña")
            return redirect("/register/?valid")

    return render(request, "users/register.html",{"miformulario":formulario_registro})


def register2(request):

    

    form = CreateUserForm()
    form2 = User_Form()

    if request.method == 'POST':
        form2 = User_Form(request.POST)
        form = CreateUserForm (request.POST)
        if form.is_valid() and User_Form:
            x = form.save()
            y = form2.save(commit=False)
            y.usuario = x
            y.save()
            form2.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'La cuenta fue creada exitosamente con el usuario:'+ user)
            return redirect('users:Login')


    users=Users.objects.all()
    return render(request, "users/register2.html",{"users":users, "form":form, "form2":form2})




def login_page (request):
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        users = authenticate(request, username=username, password=password)

        if users is not None:
            login(request, users)
            return redirect('users:Dashboard')
        else: 
            messages.info(request, 'Usuario o contraseña incorrectos')
            

    return render(request, 'users/login2.html')


def logoutUser(request):
    logout(request)
    return redirect('users:Login')


            

        
        

    

    

