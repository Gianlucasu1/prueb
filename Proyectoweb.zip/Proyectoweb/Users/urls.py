from django.urls import path
from .views import *
from django.conf import settings
from django.conf.urls.static import static

app_name='users'

urlpatterns = [

    path('', register2, name ="Register2"),
    path('login/',login_page, name ="Login"),
    path('vehiculos/',show_vehicles, name ="Vehiculos"),
    path('register/', register, name ="Register"),
    path('register2/', register2, name ="Register2"),
    path('dashboard/',dashboard, name ="Dashboard"),
]

