from django.urls import path
from .views import *
from django.conf import settings

from django.contrib.auth import views as auth_views
from django.conf.urls.static import static

app_name='users'

urlpatterns = [

    path('', register2, name ="Register2"),
    path('login/',login_page, name ="Login"),
    path('logout/',logoutUser, name ="logout"),
    path('vehiculos/',show_vehicles, name ="Vehiculos"),
    path('register/', register, name ="Register"),
    path('register2/', register2, name ="Register2"),
    path('dashboard/',dashboard, name ="Dashboard"),

    path('reset_password/',auth_views.PasswordResetView.as_view(), name = "reset_password"),
    path('reset_password_sent/',auth_views.PasswordResetDoneView.as_view(), name ="password_reset_done"),
    path('reset/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(), name = "password_reset_confirm"),
    path('reset_password_complete /',auth_views.PasswordResetCompleteView.as_view(), name = "password_reset_complete"),
]

